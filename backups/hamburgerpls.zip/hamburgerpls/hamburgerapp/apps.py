from django.apps import AppConfig


class HamburgerappConfig(AppConfig):
    name = 'hamburgerapp'
