from django.apps import AppConfig


class DojoninjaAppConfig(AppConfig):
    name = 'dojoninja_app'
