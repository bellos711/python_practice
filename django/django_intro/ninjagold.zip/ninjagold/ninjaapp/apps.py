from django.apps import AppConfig


class NinjaappConfig(AppConfig):
    name = 'ninjaapp'
