from django.apps import AppConfig


class TvappConfig(AppConfig):
    name = 'tvapp'
