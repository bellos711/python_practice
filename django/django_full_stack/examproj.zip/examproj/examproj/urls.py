
from django.urls import path, include

urlpatterns = [
    path('', include('examapp.urls'))
]
