from django.apps import AppConfig


class FavbookappConfig(AppConfig):
    name = 'favbookapp'
